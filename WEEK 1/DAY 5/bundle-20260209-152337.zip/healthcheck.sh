#!/bin/bash

SERVER_URL="http://localhost:3000"
LOG_FILE="logs/health.log"

curl -s --head --request GET "$SERVER_URL" > /dev/null

if [ $? -eq 0 ]; then
  echo "$(date) : Server UP at $SERVER_URL" >> "$LOG_FILE"
else
  echo "$(date) : Server DOWN at $SERVER_URL" >> "$LOG_FILE"
fi
